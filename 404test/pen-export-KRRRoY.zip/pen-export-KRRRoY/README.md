# Error 404 Page With Astronaut

A Pen created on CodePen.io. Original URL: [https://codepen.io/FilipVitas/pen/KRRRoY](https://codepen.io/FilipVitas/pen/KRRRoY).

