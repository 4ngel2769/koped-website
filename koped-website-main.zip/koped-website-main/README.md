<h1 align="center">
  <br>
  <a href="https://koped.angellabs.xyz"><img src="https://koped.angellabs.xyz/images/banner.png"></a>
  <br>
  KOPED - Discord bot
  <br>
</h1>


## KOPED bot's website
#### This is the source code of the KOPED Discord bot's website: **[https://diszoid.studio](https://diszoid.studio)**.
